"use client";

import Link from "next/link";
import { motion } from "motion/react";
import { Photo } from "./Photo";
import { GoButton, SaveButton, ShareButton } from "./Actions";
import { neighborhoodName } from "@/lib/neighborhoods";
import type { PickLabel, Venue } from "@/lib/types";

export function LabelChip({ label }: { label: PickLabel | string }) {
  const isPick = label === "The pick";
  return (
    <span
      className="inline-flex h-7 items-center rounded-full px-3 text-[11px] font-semibold tracking-[0.12em] uppercase"
      style={{
        background: isPick ? "var(--chalk)" : "rgba(11,12,16,0.55)",
        color: isPick ? "var(--chalk-black)" : "var(--chalk)",
        backdropFilter: "blur(10px)",
        border: isPick ? "none" : "1px solid rgba(242,240,234,0.18)",
      }}
    >
      {label}
    </span>
  );
}

export function FriendsChip({ count }: { count?: number }) {
  if (!count) return null;
  return (
    <span
      className="inline-flex h-7 items-center gap-1.5 rounded-full pl-2 pr-3 text-[12px] font-medium"
      style={{ background: "rgba(11,12,16,0.55)", backdropFilter: "blur(10px)", border: "1px solid rgba(242,240,234,0.18)" }}
    >
      <span className="flex -space-x-1.5" aria-hidden>
        {Array.from({ length: Math.min(count, 3) }).map((_, i) => (
          <span key={i} className="h-4 w-4 rounded-full border" style={{ background: ["#5f8cff", "#c04a6a", "#2f7a5a"][i % 3], borderColor: "#0b0c10" }} />
        ))}
      </span>
      {count === 1 ? "1 friend has been" : `${count} friends have been`}
    </span>
  );
}

export function VenueCard({
  venue,
  label,
  why,
  shareUrl,
  index = 0,
}: {
  venue: Venue;
  label?: PickLabel;
  why?: string;
  shareUrl: string;
  index?: number;
}) {
  return (
    <motion.article
      initial={{ opacity: 0, y: 22 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ type: "spring", stiffness: 260, damping: 28, delay: 0.05 + index * 0.08 }}
      className="card overflow-hidden"
    >
      <Link href={`/v/${venue.slug}`} className="block">
        <Photo venue={venue} rounded="rounded-none" className="aspect-[4/3] w-full">
          <div className="absolute left-4 top-4">{label && <LabelChip label={label} />}</div>
          <div className="absolute bottom-4 left-4">
            <FriendsChip count={venue.friendsBeen} />
          </div>
        </Photo>
      </Link>

      <div className="px-5 pb-5 pt-4">
        <Link href={`/v/${venue.slug}`} className="block">
          <h2 className="serif" style={{ fontSize: 28, lineHeight: 1.05, letterSpacing: "-0.015em" }}>
            {venue.name}
          </h2>
          <p className="mt-1 text-[13px]" style={{ color: "var(--chalk-55)" }}>
            {neighborhoodName(venue.neighborhood)}
          </p>
          <p className="mt-3 text-[15px] leading-[1.45]" style={{ color: "var(--chalk-70)" }}>
            {venue.take}
          </p>
        </Link>
        {(why || venue.tags.length > 0) && (
          <p className="mt-3 text-[12.5px] font-medium tracking-wide" style={{ color: "var(--chalk-55)" }}>
            {why || venue.tags.join(" · ")}
          </p>
        )}

        <div className="mt-5 flex items-center gap-2.5">
          <GoButton venue={venue} className="flex-1" />
          <SaveButton slug={venue.slug} />
          <ShareButton url={shareUrl} title={`${venue.name} — ROUND`} text={`${venue.name}, ${neighborhoodName(venue.neighborhood)}. ${venue.take}`} />
        </div>
      </div>
    </motion.article>
  );
}
